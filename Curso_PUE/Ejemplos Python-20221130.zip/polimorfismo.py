class Animal:
    def __str__(self):
        return ("valor por defecto")
    


class Perro(Animal):
    def __str__(self):
        return ("Guau!")

class Gato(Animal):
    def __str__(self):
        return ("Miau!")
    
class Canario(Animal):
    pass
    
############################3

perro = Perro()

gato = Gato()

canario = Canario()


lista_animales = [perro, gato, canario]

for animal in lista_animales:
    print(animal)